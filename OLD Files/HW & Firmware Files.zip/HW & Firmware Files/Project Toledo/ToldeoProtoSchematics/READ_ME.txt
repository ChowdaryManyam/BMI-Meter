Project Toledo, Growth Meter Device
Schematic Zip File Information
19-Jan-2023

This zip file contains OrCAD format schematics for the prototype Growth Meter Device.

ToledoProto.opj:	OrCAD format project file
ToledoProto.dsn:	OrCAD format schematic design file

There are three schematic pdf files, representing a few points along the way.

toledoproto_x03.pdf is the latest version and represents the state of the OrCAD files.


